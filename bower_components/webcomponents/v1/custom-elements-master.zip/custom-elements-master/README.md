## 🚨 Moved to [`webcomponents/polyfills/packages/custom-elements`][1] 🚨

The [`webcomponents/template`][2] repo has been migrated to [`packages/custom-elements`][1] folder of the [`webcomponents/polyfills`][3] 🚝  *monorepo*.

We are *actively* working on migrating open Issues and PRs to the new repo. New Issues and PRs should be filed at [`webcomponents/polyfills`][3].

[1]: https://github.com/webcomponents/polyfills/tree/master/packages/custom-elements
[2]: https://github.com/webcomponents/custom-elements
[3]: https://github.com/webcomponents/polyfills

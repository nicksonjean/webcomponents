import {message} from './es-module-2.js';

window.loadedModules.push('es-module-1');
import './es-module-1.js';

window.loadedModules.push('es-module-3');
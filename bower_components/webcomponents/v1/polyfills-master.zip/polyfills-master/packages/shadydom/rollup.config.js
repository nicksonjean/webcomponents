export default {
  input: 'src/shadydom.js',
  output: { file: 'shadydom.min.js', format: 'iife', sourcemap: true }
};

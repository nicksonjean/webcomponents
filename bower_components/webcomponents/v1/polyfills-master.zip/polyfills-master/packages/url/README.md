# URL
URL parser in JavaScript

This is a fork of [annevk/url](https://github.com/annevk/url). The code has been converted to pragmatic JS with a
huge performance improvement as a side effect.

# License

This is public domain.

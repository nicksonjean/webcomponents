export const message = 'foo';

window.loadedModules.push('es-module-2');
## Tests

```
npm run serve
```

Open : http://localhost:8080/tests/index.html

Replace params in `config.json`.

```
npm test
```

To clear IE cache: `RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255`
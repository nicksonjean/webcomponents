function makeNamesUpper(arr){

   return arr.map(function(elm){
    	return elm.toUpperCase();
    });
}
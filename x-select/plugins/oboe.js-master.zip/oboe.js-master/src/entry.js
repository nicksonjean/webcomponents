import { oboe } from './publicApi'

export default oboe

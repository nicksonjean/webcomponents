import { all } from './lists'
import { attr, partialComplete } from './functional'

/**
 * This file defines some loosely associated syntactic sugar for
 * Javascript programming
 */

/**
 * Returns true if the given candidate is of type T
 */
function isOfType (T, maybeSomething) {
  return maybeSomething && maybeSomething.constructor === T
}

var len = attr('length')
var isString = partialComplete(isOfType, String)

/**
 * I don't like saying this:
 *
 *    foo !=== undefined
 *
 * because of the double-negative. I find this:
 *
 *    defined(foo)
 *
 * easier to read.
 */
function defined (value) {
  return value !== undefined
}

/**
 * Returns true if object o has a key named like every property in
 * the properties array. Will give false if any are missing, or if o
 * is not an object.
 */
function hasAllProperties (fieldList, o) {
  return (o instanceof Object) &&
    all(function (field) {
      return (field in o)
    }, fieldList)
}

export {
  isOfType,
  len,
  isString,
  defined,
  hasAllProperties
}

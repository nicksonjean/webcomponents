import { list } from './lists'
import { partialComplete } from './functional'
import { hasAllProperties, isString } from './util'
import { applyDefaults } from './defaults'
import { wire } from './wire'

// export public API
function oboe (arg1) {
  // We use duck-typing to detect if the parameter given is a stream, with the
  // below list of parameters.
  // Unpipe and unshift would normally be present on a stream but this breaks
  // compatibility with Request streams.
  // See https://github.com/jimhigson/oboe.js/issues/65

  var nodeStreamMethodNames = list('resume', 'pause', 'pipe')
  var isStream = partialComplete(
    hasAllProperties,
    nodeStreamMethodNames
  )

  if (arg1) {
    if (isStream(arg1) || isString(arg1)) {
      //  simple version for GETs. Signature is:
      //    oboe( url )
      //  or, under node:
      //    oboe( readableStream )
      return applyDefaults(
        wire,
        arg1 // url
      )
    } else {
      // method signature is:
      //    oboe({method:m, url:u, body:b, headers:{...}})

      return applyDefaults(
        wire,
        arg1.url,
        arg1.method,
        arg1.body,
        arg1.headers,
        arg1.withCredentials,
        arg1.cached
      )
    }
  } else {
    // wire up a no-AJAX, no-stream Oboe. Will have to have content
    // fed in externally and using .emit.
    return wire()
  }
}

/* oboe.drop is a special value. If a node callback returns this value the
   parsed node is deleted from the JSON
 */
oboe.drop = function () {
  return oboe.drop
}

export { oboe }

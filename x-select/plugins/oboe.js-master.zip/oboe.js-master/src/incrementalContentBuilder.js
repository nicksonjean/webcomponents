import { SAX_KEY, SAX_VALUE_CLOSE, SAX_VALUE_OPEN, NODE_OPENED, NODE_CLOSED, ROOT_PATH_FOUND, ROOT_NODE_FOUND } from './events'
import { namedNode, nodeOf, keyOf } from './ascent'
import { isOfType, len } from './util'
import { head, tail, cons } from './lists'

/**
 * This file provides various listeners which can be used to build up
 * a changing ascent based on the callbacks provided by Clarinet. It listens
 * to the low-level events from Clarinet and emits higher-level ones.
 *
 * The building up is stateless so to track a JSON file
 * ascentManager.js is required to store the ascent state
 * between calls.
 */

/**
 * A special value to use in the path list to represent the path 'to' a root
 * object (which doesn't really have any path). This prevents the need for
 * special-casing detection of the root object and allows it to be treated
 * like any other object. We might think of this as being similar to the
 * 'unnamed root' domain ".", eg if I go to
 * http://en.wikipedia.org./wiki/En/Main_page the dot after 'org' deliminates
 * the unnamed root of the DNS.
 *
 * This is kept as an object to take advantage that in Javascript's OO objects
 * are guaranteed to be distinct, therefore no other object can possibly clash
 * with this one. Strings, numbers etc provide no such guarantee.
 **/
var ROOT_PATH = {}

/**
 * Create a new set of handlers for clarinet's events, bound to the emit
 * function given.
 */
function incrementalContentBuilder (oboeBus) {
  var emitNodeOpened = oboeBus(NODE_OPENED).emit
  var emitNodeClosed = oboeBus(NODE_CLOSED).emit
  var emitRootOpened = oboeBus(ROOT_PATH_FOUND).emit
  var emitRootClosed = oboeBus(ROOT_NODE_FOUND).emit

  function arrayIndicesAreKeys (possiblyInconsistentAscent, newDeepestNode) {
    /* for values in arrays we aren't pre-warned of the coming paths
         (Clarinet gives no call to onkey like it does for values in objects)
         so if we are in an array we need to create this path ourselves. The
         key will be len(parentNode) because array keys are always sequential
         numbers. */

    var parentNode = nodeOf(head(possiblyInconsistentAscent))

    return isOfType(Array, parentNode)
      ? keyFound(possiblyInconsistentAscent,
        len(parentNode),
        newDeepestNode
      )
      // nothing needed, return unchanged
      : possiblyInconsistentAscent
  }

  function nodeOpened (ascent, newDeepestNode) {
    if (!ascent) {
      // we discovered the root node,
      emitRootOpened(newDeepestNode)

      return keyFound(ascent, ROOT_PATH, newDeepestNode)
    }

    // we discovered a non-root node

    var arrayConsistentAscent = arrayIndicesAreKeys(ascent, newDeepestNode)
    var ancestorBranches = tail(arrayConsistentAscent)
    var previouslyUnmappedName = keyOf(head(arrayConsistentAscent))

    appendBuiltContent(
      ancestorBranches,
      previouslyUnmappedName,
      newDeepestNode
    )

    return cons(
      namedNode(previouslyUnmappedName, newDeepestNode),
      ancestorBranches
    )
  }

  /**
    * Add a new value to the object we are building up to represent the
    * parsed JSON
    */
  function appendBuiltContent (ancestorBranches, key, node) {
    nodeOf(head(ancestorBranches))[key] = node
  }

  /**
    * For when we find a new key in the json.
    *
    * @param {String|Number|Object} newDeepestName the key. If we are in an
    *    array will be a number, otherwise a string. May take the special
    *    value ROOT_PATH if the root node has just been found
    *
    * @param {String|Number|Object|Array|Null|undefined} [maybeNewDeepestNode]
    *    usually this won't be known so can be undefined. Can't use null
    *    to represent unknown because null is a valid value in JSON
    **/
  function keyFound (ascent, newDeepestName, maybeNewDeepestNode) {
    if (ascent) { // if not root
      // If we have the key but (unless adding to an array) no known value
      // yet. Put that key in the output but against no defined value:
      appendBuiltContent(ascent, newDeepestName, maybeNewDeepestNode)
    }

    var ascentWithNewPath = cons(
      namedNode(newDeepestName,
        maybeNewDeepestNode),
      ascent
    )

    emitNodeOpened(ascentWithNewPath)

    return ascentWithNewPath
  }

  /**
    * For when the current node ends.
    */
  function nodeClosed (ascent) {
    emitNodeClosed(ascent)

    return tail(ascent) ||
      // If there are no nodes left in the ascent the root node
      // just closed. Emit a special event for this:
      emitRootClosed(nodeOf(head(ascent)))
  }

  var contentBuilderHandlers = {}
  contentBuilderHandlers[SAX_VALUE_OPEN] = nodeOpened
  contentBuilderHandlers[SAX_VALUE_CLOSE] = nodeClosed
  contentBuilderHandlers[SAX_KEY] = keyFound
  return contentBuilderHandlers
}

export { incrementalContentBuilder, ROOT_PATH }
